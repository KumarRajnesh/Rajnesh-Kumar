# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 02:06:18 2024

@author: Rajnesh Kumar
"""

from CoolProp.CoolProp  import PropsSI
import numpy as np
import matplotlib.pyplot as plt

def refrigeration_cycle_model(Q_cooling_peak, T_building, T_outside, T_sc, T_sh, DT_eva, DT_cond, eta_is_comp, eta_electric, Ref):

  # Convert temperatures to Kelvin
  T_building = T_building + 273.15
  T_outside = T_outside + 273.15

  # Define state points
  T = np.zeros((8, 1))
  s = np.zeros((8, 1))
  P = np.zeros((8, 1))
  h = np.zeros((8, 1))
  
  # Define Evaporator & Condenser Temperatures
  T_eva = T_building - DT_eva
  T_cond = T_outside + DT_cond

  # Compressor inlet (State 1)
  T[0] = T_building - DT_eva + T_sh
  P_eva = PropsSI('P', 'T', T_eva, 'Q', 1, Ref)
  P[0] = P_eva
  h[0] = PropsSI('H', 'T', T[0], 'P', P[0], Ref)
  s[0] = PropsSI('S', 'T', T[0], 'P', P[0], Ref)

  # Compressor Outlet (State 2)
  s_1is = s[0]
  P_cond = PropsSI('P', 'T', T_cond, 'Q', 1, Ref)
  P[1] = P_cond
  h_1is = PropsSI('H', 'S', s_1is, 'P', P_cond, Ref)
  h[1] = h[0] + (h_1is - h[0]) / eta_is_comp
  s[1] = PropsSI('S', 'H', h[1], 'P', P_cond, Ref)
  T[1] = PropsSI('T', 'H', h[1], 'P', P_cond, Ref)

  # Condenser saturated vapor point (State 3)
  P[2] = P_cond
  h[2] = PropsSI('H', 'P', P[2], 'Q', 1, Ref)
  T[2] = T_outside + DT_cond
  s[2] = PropsSI('S', 'P', P[2], 'Q', 1, Ref)

  # Condenser Saturated Liquid point (State 4)
  P[3] = P_cond
  h[3] = PropsSI('H', 'P', P[3], 'Q', 0, Ref)
  T[3] = T_outside + DT_cond
  s[3] = PropsSI('S', 'P', P[3], 'Q', 0, Ref)

  # Condenser Outlet (State 5)
  T[4] = T_cond - T_sc
  P[4] = P_cond
  h[4] = PropsSI('H', 'T', T[4], 'P', P[4], Ref)
  s[4] = PropsSI('S', 'T', T[4], 'P', P[4], Ref)

  # Expansion Valve Outlet (State 6)
  P[5] = P_eva
  h[5] = h[4]
  s[5] = PropsSI('S', 'H', h[5], 'P', P[5], Ref)
  T[5] = PropsSI('T', 'H', h[5], 'S', s[5], Ref)

  # Evaporator saturated vapor point (State 7)
  P[6] = P_eva
  h[6] = PropsSI('H', 'P', P[6], 'Q', 1, Ref)
  T[6] = T_eva
  s[6] = PropsSI('S', 'P', P[6], 'Q', 1, Ref)

  # Evaporator Exit (State 8)
  T[7] = T[0]
  s[7] = s[0]
  h[7] = h[0]
  P[7] = P[0]

  # Cycle mass flow rate
  m_cycle = Q_cooling_peak / (h[0] - h[5])

  # Compressor Work
  W_comp = m_cycle * (h[1] - h[0])

  # Electric Work
  W_electric = W_comp / eta_electric

  # COP of cycle with respect to compressor work
  COP_cycle = Q_cooling_peak / W_comp

  # COP of cycle with respect to customer perspective
  COP_customer = Q_cooling_peak / W_electric

  return T, s, P, h, m_cycle, W_comp, W_electric, COP_cycle, COP_customer


def plot_temperature_entropy(refrigerant_name, temperature_range_min):
  """
  This function plots the temperature vs. entropy for a given refrigerant or liquid.

  Args:
      refrigerant_name (str): Name of the refrigerant or liquid (e.g., "R600a", "Water").
      temperature_range_min (float): Minimum temperature in Kelvin.
  """

  # Get critical temperature
  t_crit = PropsSI(refrigerant_name, 'Tcrit')

  # Create temperature range as a NumPy array
  temperature_range = np.linspace(temperature_range_min, t_crit, 200)

  # Initialize empty lists for entropy values
  s_before = []
  s_after = []

  # Calculate entropy for saturated liquid and vapor states
  for temperature in temperature_range:
    entropy_before = PropsSI('S', 'T', temperature, 'Q', 0, refrigerant_name)
    entropy_after = PropsSI('S', 'T', temperature, 'Q', 1, refrigerant_name)
    s_before.append(entropy_before)
    s_after.append(entropy_after)

  # Create the plot
  plt.plot(s_before, temperature_range, label='Saturated Liquid')
  plt.plot(s_after, temperature_range, label='Saturated Vapor')
  plt.ylabel('Temperature (K)')
  plt.xlabel('Entropy (J/kg/K)')
  plt.title(f'Temperature vs. Entropy ({refrigerant_name})')
  plt.legend()
  plt.grid(True)
  

def plot_pressure_enthalpy(refrigerant_name, pressure_range_min):
  """
  This function plots the pressure vs. entropy for a given refrigerant or liquid.

  Args:
      refrigerant_name (str): Name of the refrigerant or liquid (e.g., "R600a", "Water").
      pressure_range_min (float): Minimum pressure in Pa.
  """

  # Get critical pressure
  p_crit = PropsSI(refrigerant_name, 'Pcrit')

  # Create pressure range as a NumPy array
  pressure_range = np.linspace(pressure_range_min, p_crit, 200)

  # Initialize empty lists for enthalpy values
  h_left = []
  h_right = []

  # Calculate enthalpy for saturated liquid and vapor states
  for pressure in pressure_range:
    enthalpy_left = PropsSI('H', 'P', pressure, 'Q', 0, refrigerant_name)
    enthalpy_right = PropsSI('H', 'P', pressure, 'Q', 1, refrigerant_name)
    h_left.append(enthalpy_left)
    h_right.append(enthalpy_right)

  # Create the plot
  plt.plot(h_left, pressure_range, label='Saturated Liquid')
  plt.plot(h_right, pressure_range, label='Saturated Vapor')
  plt.ylabel('Pressure (Pa)')
  plt.xlabel('Enthalpy (J/kg)')
  plt.title(f'Pressure vs. Enthalpy ({refrigerant_name})')
  plt.legend()
  plt.grid(True)
  
  