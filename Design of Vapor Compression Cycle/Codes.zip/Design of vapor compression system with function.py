# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 16:08:18 2024

@author: Rajnesh Kumar
"""

from functions_file import refrigeration_cycle_model, plot_temperature_entropy, plot_pressure_enthalpy
import matplotlib.pyplot as plt
import numpy as np

# Data
Q_cooling_peak = 63000
T_building = 22.5
T_outside = 35
T_sc = 3
T_sh = 3
DT_eva = 10
DT_cond = 4
eta_is_comp = 0.8
eta_electric = 0.95
Ref = "R600a"


T, s, P, h, m_cycle, W_comp, W_electric, COP_cycle, COP_customer = refrigeration_cycle_model(Q_cooling_peak, T_building, T_outside, T_sc, T_sh, DT_eva, DT_cond, eta_is_comp, eta_electric, Ref)

print(f"The mass flowrate of the cycle is: {m_cycle} kg/s")
print(f"The compressor work is: {W_comp} W")
print(f"The electric power required by the compressor is: {W_electric} W")
print(f"The COP of the system is: {COP_cycle}")
print(f"The COP of the system from customer's perspective is: {COP_customer}")
      
# Plot temperature vs entropy
plot_temperature_entropy(Ref, 273.15)
plt.plot(s, T, label = "Cycle")
plt.annotate("1", xy=(s[0], T[0]), xytext=(5, -4), textcoords="offset points")
plt.annotate("2", xy=(s[1], T[1]), xytext=(5, 0), textcoords="offset points")
plt.annotate("3", xy=(s[4], T[4]), xytext=(-10, 0), textcoords="offset points")
plt.annotate("4", xy=(s[5], T[5]), xytext=(-10, 0), textcoords="offset points")
plt.plot(np.linspace(s[4]-100, s[1]+100, 100), np.ones_like(np.linspace(s[4]-1000, s[1]+1000, 100))*(T_building+273.15), linestyle='--', color='blue', label='Building Temperature')
plt.plot(np.linspace(s[4]-100, s[1]+100, 100), np.ones_like(np.linspace(s[4]-1000, s[1]+1000, 100))*(T_outside+273.15), linestyle='--', color='red', label='Outside Temperature')
plt.legend()
plt.show()

# Plot pressure vs enthalpy
plot_pressure_enthalpy(Ref, 101325)
plt.plot(h, P, label = 'Cycle')
plt.annotate("1", xy=(h[0], P[0]), xytext=(5, -5), textcoords="offset points")
plt.annotate("2", xy=(h[1], P[1]), xytext=(5, 0), textcoords="offset points")
plt.annotate("3", xy=(h[4], P[4]), xytext=(-10, 0), textcoords="offset points")
plt.annotate("4", xy=(h[5], P[5]), xytext=(-10, 0), textcoords="offset points")
plt.legend()
plt.show()



